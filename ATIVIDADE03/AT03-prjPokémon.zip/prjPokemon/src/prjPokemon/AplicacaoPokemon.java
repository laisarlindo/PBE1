package prjPokemon;

public class AplicacaoPokemon {

	public static void main(String[] args) {
		
		Pokemon p1 = new Pokemon ("Pikachu" , " electric", 10, 100 );
		Pokemon p2 = new Pokemon ("Raichu", "electric", 12,119);
		Pokemon p3 = new Pokemon ("Sandshew", "ground", 23,200);
		Pokemon p4 = new Pokemon ("Nidoran", "poison", 17,210);
		Pokemon p5 = new Pokemon ("Vulpix", "fire", 20, 300);
		
		p1.atacar();
		p1.evoluir();
		
		p2.atacar();
		p2.evoluir();
		
		p3.atacar();
		p3.evoluir();
		
		p4.atacar();
		p4.evoluir();
		
		p5.atacar();
		p5.evoluir();
	}

}
