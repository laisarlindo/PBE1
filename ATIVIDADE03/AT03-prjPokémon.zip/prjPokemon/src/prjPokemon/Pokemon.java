package prjPokemon;

public class Pokemon {
	//ATRIBUTOS
		String Nome;
		String Tipo;
		double Nivel;
		double Hp;
		
		//CONSTRITORES
		public Pokemon() {
			
		}
		public Pokemon(String Nome, String Tipo,double Nivel, double Hp) {
			this.Nome = Nome;
			this.Tipo = Tipo;
			this.Nivel = Nivel;
			this.Hp = Hp;
		}
			
			//MÉTODOS
			public void atacar() {
				System.out.println(this.Nome + "O ataque ocorreu com sucesso");
				}
			public void evoluir () {
				System.out.println(this.Nome + "O pokemon evolui com sucesso");
			}
}
