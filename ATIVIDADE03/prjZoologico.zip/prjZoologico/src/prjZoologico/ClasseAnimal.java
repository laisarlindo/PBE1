package prjZoologico;

public class ClasseAnimal {
	//ATRIBUTOS
	String atributoNome;
	String atributoRaca;
	String atributoSexo;
	double atributoPeso;
	
	//CONSTRITORES
	public ClasseAnimal() {
		
	}
	public ClasseAnimal(String parametroNome, String parametroRaca,String parametroSexo, double parametroPeso) {
		this.atributoNome = parametroNome;
		this.atributoRaca = parametroRaca;
		this.atributoSexo = parametroSexo;
		this.atributoPeso = parametroPeso;
	}
    //MÉTODOS
	public void metodoComer () {
		if (this.atributoPeso >= 170) {
			System.out.println(this.atributoNome + "está obeso, vamos exercitar");
		}
		else {
			this.atributoPeso += 10;
		}
		
	}
	public void metedoExercitar() {
		if(this.atributoPeso <= 50) {
			System.out.println(this.atributoNome + "Que tal se alimentar?");	
		}
		else {
			this.atributoPeso -= 10;
		}
	}
	public void exibirInfo() {
		System.out.println("Nome: " + this.atributoNome);
		System.out.println("Peso: " + this.atributoPeso );
	}
}
