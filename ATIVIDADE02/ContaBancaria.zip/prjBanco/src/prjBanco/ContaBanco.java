package prjBanco;

import java.util.Scanner;

public class ContaBanco {

	public static void main(String[] args) {
	Scanner sc = new Scanner (System.in);
	
	//OBJETOS
	ContaBancaria contaBanco01 = new ContaBancaria();
	
	System.out.println("Qual é o nome titular?");
	contaBanco01.setnomeTitular(sc.nextLine());
	
	System.out.println("Qual o numero da conta?");
	contaBanco01.setnumeroConta(sc.nextInt());
	
	System.out.println("Qual  é o saldo da conta ?");
	contaBanco01.setSaldo (sc.nextDouble());
	//OPÇÕES-ESCOLHAS
	System.out.println("Opções:");
	System.out.println("1. Sacar");
	System.out.println("2. Depositar");
	System.out.println("Escolha uma opção");
	int escolha = sc.nextInt();
	//CHAMANDO OS MÉTODOS
	if (escolha == 1) {
		System.out.println("Quanto você quer sacar?");
		contaBanco01.sacar(sc.nextDouble());
	}
	else if (escolha == 2) {
		System.out.println("Quanto você quer depositar ? ");
		contaBanco01.depositar(sc.nextDouble());
	}
	else {
		System.out.println("Opção Inválida");
	}
    // EXIBIÇÃO FINAL
	System.out.println("nomeTilular"+ contaBanco01.getnomeTitular());
	System.out.println("numeroConta"+ contaBanco01.getnumeroConta());
	System.out.println("saldo" + contaBanco01.getSaldo());
	sc.close();
	}

}
