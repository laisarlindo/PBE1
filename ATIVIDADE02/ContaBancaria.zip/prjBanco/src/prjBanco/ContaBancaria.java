package prjBanco;

public class ContaBancaria {
	//ATRIBUTOS
	private int numeroConta;
	private String nomeTitular;
	private double Saldo;
	
	// CONSTRUTORES
	public ContaBancaria(int numeroConta,String nomeTitular, double Saldo){
		
		 this.numeroConta= numeroConta;
		 this.nomeTitular = nomeTitular;
		 this.Saldo = Saldo;
	}
	public ContaBancaria() {
	}
	
	//Getters Setters
	public int getnumeroConta() {
		return numeroConta;
	}
	public void setnumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
		
	}
	public String getnomeTitular() {
		return nomeTitular;
	}
	public void setnomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}
	public void setSaldo(double Saldo) {
		if(Saldo <0 ) {
			System.out.println("O saldo não pode ser nagativa");
			this.Saldo = 0;
		}
		else {
			this.Saldo = Saldo;
		}
		
	}
	public double getSaldo() {
		return Saldo;
	}

   // MÉTODOS
void depositar(double depositar) {
	Saldo += depositar;
}
void sacar(double sacar) {
	if (Saldo > sacar) { // Verificando quanto há de saldo na conta
		Saldo -= sacar;
}
}
void exibirInformacao () {
	System.out.println("Nome : " + nomeTitular);
	System.out.println("Saldo : " + Saldo);
	System.out.println("Numero da conta : " + numeroConta);
}
}

