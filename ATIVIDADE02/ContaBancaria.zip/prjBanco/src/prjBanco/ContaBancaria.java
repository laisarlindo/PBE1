package prjBanco;

public class ContaBancaria {
	//ATRIBUTOS
	private int numeroConta;
	private String nomeTitular;
	private double Saldo;
	
	// CONSTRUTORES
	public ContaBancaria(int numeroConta,String nomeTitular, double Saldo){
		
		 this.numeroConta= numeroConta;
		 this.nomeTitular = nomeTitular;
		 this.Saldo = Saldo;
	}
	public ContaBancaria() {
	}
	
	//Getters Setters
	
}
