package prjPokemonV2;

public class aplicacao {

	public static void main(String[] args) {
		Pokemon p1 = new PokemonFogo();
		Pokemon p2 = new PokemonFogo() ;
		Pokemon p3 = new PokemonAgua(); 
		Pokemon p4 = new PokemonAgua();
		Pokemon p5 = new pokemonVoador();
		Pokemon p6 = new pokemonVoador();
		Pokemon p7 = new Pokemon();
		Pokemon p8 = new Pokemon();
		
		//POKÉMONS DE FOGO
		p1.setNome("Chamander");
		p1.setTipo("Fogo");
		p1.setNivel(14);
		p1.setHp(120);
		p1.setDefesa(100);
		
		p1.atacar();
		p1.evoluir();
		p1.exibirInfo();
		
		p2.setNome("Charmeleon");
		p2.setTipo("Fogo");
		p2.setNivel(23);
		p2.setHp(123);
		p2.setDefesa(100);
		
		p2.atacar();
		p2.evoluir();
		p2.exibirInfo();
		
		//POKÉMONS DE ÁGUA
		p3.setNome("Wartortle");
		p3.setTipo("Água");
		p3.setNivel(20);
		p3.setHp(100);
		p3.setDefesa(100);
		
		
		p3.atacar();
		p3.evoluir();
		p3.exibirInfo();
		
		p4.setNome("Squitirtle");
		p4.setTipo("Água");
		p4.setNivel(30);
		p4.setHp(100);
		p4.setDefesa(100);
		
		p4.atacar();
		p4.evoluir();
		p4.exibirInfo();
		
		//POKÉMONS VOADORES
		p5.setNome("Pidegey");
		p5.setTipo("Voador");
		p5.setNivel(40);
		p5.setHp(100);
		p5.setDefesa(100);
		
		p5.atacar();
		p5.evoluir();
		p5.exibirInfo();
		
		p6.setNome("Pidgeot");
		p6.setTipo("Voador");
		p6.setNivel(50);
		p6.setHp(100);
		p6.setDefesa(100);
		
		p6.atacar();
		p6.evoluir();
		p6.exibirInfo();
		
		//POKÉMONS NORMAIS
		p7.setNome("Pikachu");
		p7.setTipo("Normal");
		p7.setNivel(20);
		p7.setHp(100);
		p7.setDefesa(100);
		
		p7.atacar();
		p7.evoluir();
		p7.exibirInfo();
		
		p8.setNome("Nidoran");
		p8.setTipo("Normal");
		p8.setNivel(10);
		p8.setHp(100);
		p8.setDefesa(100);
		
		p8.atacar();
		p8.evoluir();
		p8.exibirInfo();
		
	}

}
