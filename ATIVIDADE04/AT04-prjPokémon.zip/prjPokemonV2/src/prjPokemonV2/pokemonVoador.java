package prjPokemonV2;

public class pokemonVoador extends Pokemon {
	//MÉTODOS DA SUBCLASSE
	@Override
	public void atacar() {
		System.out.println(this.getNome()+ "Fez ataques com sucesso");
	}
	public void voar() {
		System.out.println(this.getNome() + "O voo ocorreu com sucesso");
		}
	
	public void atacaqueAsa () {
		System.out.println(this.getNome() + "O pokemon faz ataque asa com sucesso");
}
}