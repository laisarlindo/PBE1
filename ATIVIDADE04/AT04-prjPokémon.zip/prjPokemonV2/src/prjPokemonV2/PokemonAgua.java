package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	//MÉTODOS DA SUBCLASSE
	@Override
	public void atacar() {
		System.out.println(this.getNome() + "O clima esfriou com sua água");
	}
	public void surfar() {
		System.out.println(this.getNome() + "Fez um belo surf");
	}
	public void canhaoAgua() {
		System.out.println(this.getNome() + "Fez um lindo canhão de água");
	}
 
}
