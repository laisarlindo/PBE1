package prjPokemonV2;

public class Pokemon {
	//ATRIBUTOS
 private String Nome;
 private String Tipo;
 private int   Nivel;
 private int   Hp;
 private int   Defesa;
 
 	//CONSTRUTORES
 public Pokemon () {
	 
 }
 public Pokemon (String Nome, String Tipo, int Nivel, int Hp,int Defesa) {
	 this.Nome  = Nome;
	 this.Tipo  = Tipo;
	 this.Nivel = Nivel;
	 this.Hp    = Hp;
	 this.Defesa= Defesa; 
 }
  	//GETTERS E SETTERS
 public String getNome() {
	return Nome;
}
 public void setNome(String nome) {
	Nome = nome;
}
 public String getTipo() {
	return Tipo;
}
 public void setTipo(String tipo) {
	Tipo = tipo;
}
 public int getNivel() {
	return Nivel;
}
 public void setNivel(int nivel) {
	Nivel = nivel;
}
 public int getHp() {
	return Hp;
}
 public void setHp(int hp) {
	Hp = hp;
}
 public int getDefesa() {
	return Defesa;
}
 public void setDefesa(int defesa) {
	Defesa = defesa;
}
 	//MÉTODOS
 	public void atacar() {
		System.out.println(this.Nome + "O ataque ocorreu com sucesso");
		}
	public void evoluir () {
		System.out.println(this.Nome + "O pokemon evolui com sucesso");
	}
	public void exibirInfo() {
		System.out.println("Nome:" + this.Nome);
		System.out.println("Tipo:" + this.Tipo);
		System.out.println("Nivel:"+ this.Nivel);
		System.out.println("Hp:"   + this.Hp);
		System.out.println("Defesa:"+ this.Defesa);
	}
}
 
 
 
 
 
 

