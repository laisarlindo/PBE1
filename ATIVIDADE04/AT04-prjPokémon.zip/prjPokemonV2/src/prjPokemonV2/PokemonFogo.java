package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	//MÉTODOD DA SUBCLASSE
	@Override
	public void atacar() {
		System.out.println(this.getNome() + "O clima esquentou com seu fogo");
	}
	public void bolaFogo() {
		System.out.println("POW");
	}
	public void explosaoFogo() {
		System.out.println("BUM");
	}
	public void lancaChmas() {
		System.out.println(this.getNome() + "Lançou chamas com sucesso");
	}
	
}
