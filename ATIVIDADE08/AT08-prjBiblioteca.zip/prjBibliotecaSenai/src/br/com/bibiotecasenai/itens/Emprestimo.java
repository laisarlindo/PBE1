package br.com.bibiotecasenai.itens;

import br.com.bibiotecasenai.usuarios.*;

public class Emprestimo extends Usuario {
	//ATRIBUTOS
	
	int numeroEmprestimo;
	
	//MÉTODOS
	
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()+1);	
	}
	public void devolverLivro (Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()-1);
		
	}

}
