package br.com.bibiotecasenai.usuarios;

public class Pessoa {
	//ATRIBUTOS
	private String nome;
	private int idade;
	
	//CONSTRUTORES
	public Pessoa() {
		
	}
	public Pessoa(String nome,int idade) {
		this.idade = idade;
		this.nome = nome;
		
	}
	//GETTERS E SETTERS
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	

}
