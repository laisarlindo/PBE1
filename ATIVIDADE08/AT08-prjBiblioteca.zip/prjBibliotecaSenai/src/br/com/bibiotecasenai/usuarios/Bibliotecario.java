package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	
	//ATRIBUTOS DA SUBCLASSE
	
	String matricula;
	
	//MÉTODOS DA SUBCLASSE
	
	public void realizarEmprestimo() {
		System.out.println(getNome() + "Realizou o emprestimo");
	}
	public void devolverLivro() {
		System.out.println(getNome() + " devolveu livro");
	}

}
