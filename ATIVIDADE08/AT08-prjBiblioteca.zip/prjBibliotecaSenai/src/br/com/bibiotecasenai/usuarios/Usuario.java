package br.com.bibiotecasenai.usuarios;

public class Usuario extends Pessoa {
	
	//ATRIBUTOS DA SUBCLASSE
	private int CPF;
	private int  livrosEmprestados;
	
	//CONSTRUTORES
	public Usuario() {
		
	}
	public Usuario(int CPF,int livrosEmprestados) {
		this.CPF = CPF;
		this.livrosEmprestados = livrosEmprestados;
		
	}
	//GETTERS E SETTERS
	public int getCPF() {
		return CPF;
	}
	public void setCPF(int cPF) {
		CPF = cPF;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	
	

}
