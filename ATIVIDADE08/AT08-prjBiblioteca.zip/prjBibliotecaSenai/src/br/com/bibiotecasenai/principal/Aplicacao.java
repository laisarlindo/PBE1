package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Bibliotecario;
import br.com.bibiotecasenai.usuarios.Usuario;
import br.com.bibiotecasenai.itens.*;

public class Aplicacao {

	public static void main(String[] args) {
		
		Emprestimo u1= new Emprestimo();
		u1.setNome("Evellyn");
		u1.setCPF(477908769);
		u1.setIdade(18);
		
		for(int i = 0; i <10; i++) {
		u1.emprestarLivro(null, u1);
		System.out.println("Um livro foi emprestado " + i);
		}
	
		for (int i = 0; i<8; i--) {
		u1.devolverLivro(null,u1);
		System.out.println("Um livro foi devolvido" + i);
		}
		
		Emprestimo u2 = new Emprestimo();
		u2.setNome("Bruna");
		u2.setCPF(97787640);
		u2.setIdade(30);
		
		for(int i = 0; i <10; i++) {
			u1.emprestarLivro(null, u2);
			System.out.println("Um livro foi emprestado " + i);
			}
			
			for (int i = 0; i<8; i--) {
			u1.devolverLivro(null,u1);
			System.out.println("Um livro foi devolvido" + i);
			}
		Bibliotecario b1 = new Bibliotecario();
		b1.setIdade(34);
		b1.setNome("Luiza");

	}

}
