package br.com.senaimusic.modelos;

public class Audio {
	//ATRIBUTOS
	private String titulo;
	private int totalReproducoes;
	private int totalCurtidas;
	private double classificacao;
	
	//CONSTRUTORES
		public Audio () {
			
		}
		public Audio(String titulo) {
			this.titulo = titulo;
			this.totalCurtidas = 0;
			this.totalReproducoes = 0;
			this.classificacao = 0;
			
		}
		//GETTERS E SETTERS
		public void setTitulo (String titulo) {
			this.titulo = titulo;
		}
		public String getTitulo() {
			return this.titulo;
		}
		public int getTotalReproducoes() {
			return this.totalReproducoes;
		}
		public int getTotalCurtidas() {
			return this.totalCurtidas;
		}
		public double getClassificacao() {
			return this.classificacao;
		}
	
	//MÉTODOS
	public void curte() {
		this.totalCurtidas++;
	}
	public void reproduz() {
		this.totalReproducoes++;
	}
	
	
	}
	


