package prjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System .in);
		
		System.out.println("Qual é a marca do carro?");
		String marca = sc.nextLine();
		
		System.out.println("Qual é o modelo do carro?");
		String modelo = sc.nextLine();
		
		System.out.println("Em qual velocidade o carro se encontra?");
		int velocidade = sc.nextInt();
		
		System.out.println("Você deseja acelerar, digite 1 ou  freiar? digite 2");
		int  resposta = sc.nextInt();
		
		if ( resposta == 1) {
			System.out.println("Quanto?");
			int acelerar = sc.nextInt();
			velocidade += acelerar; 
		}
		else if (resposta == 2) {
			System.out.println("Quanto?");
			int  freiar = sc.nextInt();
			velocidade -= freiar;
		}
		System.out.println(" O carro da "+ marca  +"do " + modelo + "se encontra na velocidade "+ velocidade + "Km/h");
		

	}

}
