package prjExercio01;

public class carroAplicacao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Carro c1 = new Carro("BYD","Ouro",344000,"Bruna");
		Carro c2 = new Carro("Newjeans","Ditto",20300,"Lais");
		
		c1.exibirInfo();
		c2.exibirInfo();

	}

}
