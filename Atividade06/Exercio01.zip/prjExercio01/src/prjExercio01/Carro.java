package prjExercio01;

public class Carro {
	//ATRIBUTOS
	private String Marca;
	private String Modelo;
	private int    Preco;
	private String Dono;
	
	//CONSTRUTORES
	public Carro() {
		
	}
	public Carro(String Marca,String Modelo, int Preco, String Dono ) {
		this.Marca = Marca;
		this.Modelo = Modelo;
		this.Preco = Preco;
		this.Modelo = Modelo;
	}
	//MÉTODOS
	public void exibirInfo() {
		System.out.println("Marca:" + this.Marca);
		System.out.println("Modelo" + this.Modelo);
		System.out.println("Preco:" + this.Preco);
		System.out.println("Dono:"  + this.Dono);
	}
	
	
}
