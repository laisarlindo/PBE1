package prjExercio05;

public class ContaPoupanca extends ContaBancaria {
	//ATRIBUTO DA SUBCLASSE
	
	double TaxaJuros;
	
	//MÉTODOS DA SUBCLASSE
	public void CalcularJuros(int meses) {
		setSaldo(getSaldo() + (meses*TaxaJuros));
	}
}
