package prjExercio03;

public class Leao extends Animal {
	
	//MÉTODOS DA SUBCLASSE
	
	public void Cacar () {
		System.out.println("O leão esta a cacar");
	}

}
