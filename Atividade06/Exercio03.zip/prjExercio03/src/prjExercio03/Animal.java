package prjExercio03;

public class Animal {
	//ATRIBUTOS
	 String nome;
	 int    idade;
	 String raca;
	
	//CONSTRUTORES
	public Animal () {
		
	}
	public Animal(String nome, int idade,String raca) {
		this.nome = nome;
		this.idade = idade;
		this.raca = raca;
	}
	
	//MÉTODOS
	public void fazerSom () {
		System.out.println(this.nome + "Fez um som");
	}

}
