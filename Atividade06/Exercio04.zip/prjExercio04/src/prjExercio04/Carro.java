package prjExercio04;

public class Carro extends Veiculo {
	//MÉTODOS DA SUBCLASSE
	
	@Override
	public void acelerar() {
		System.out.println(this.velocidade + "O carro esta acelerando");
		this.velocidade+=10;

	}
	public void frar() {
		System.out.println(this.velocidade + "O carro esta freando");
		this.velocidade -= 10;

}
}
