package prjExercio04;

public class Veiculo {
	//ATRIBUTOS
	String marca;
	String modelo;
	int    velocidade;
	
	//CONSTRUTORES
	
	public Veiculo() {
		
	}
	public Veiculo (String marca,String modelo,int Velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidade = velocidade;
		
		
	}
	//MÉTODOS
	public void acelerar() {
		System.out.println(this.velocidade + "Veiculo Acelerando");
		this.velocidade+=10;

	}
	public void frar() {
		System.out.println(this.velocidade + "Veiculo Freando");
		this.velocidade -= 10;
	}

}
