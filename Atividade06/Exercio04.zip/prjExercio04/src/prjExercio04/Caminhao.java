package prjExercio04;

public class Caminhao extends Veiculo {
	//MÉTODOS DA SUBCLASSE
	
	@Override
	public void acelerar() {
		System.out.println(this.velocidade + "O caminhão esta acelerando");
		this.velocidade+=10;

	}
	public void frar() {
		System.out.println(this.velocidade + "O caminhão esta freando");
		this.velocidade -= 10;

}
}



