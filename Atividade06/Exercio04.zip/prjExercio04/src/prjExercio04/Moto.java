package prjExercio04;

public class Moto extends Veiculo {
	
	//MÉTODOS DA SUBCLASSE
	@Override 
	
	public void acelerar() {
		System.out.println(this.velocidade + "A moto esta acelerando");
		this.velocidade+=10;

	}
	public void frar() {
		System.out.println(this.velocidade + "A moto esta freando");
		this.velocidade -= 10;

}
}
