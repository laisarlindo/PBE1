package prjExercio03;

public class Baleia extends Animal {
	
	//MÉTODOS DA SUBCLASSE
	
	public void nadar() {
		System.out.println( "Esta a nadar");
	}
	

}
